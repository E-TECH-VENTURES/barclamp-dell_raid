// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Node Discovered Alerts',
    injectableName: 'Task.Base.Alert.Node.Discovered',
    runJob: 'Job.Alert.Node.Discovered',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
