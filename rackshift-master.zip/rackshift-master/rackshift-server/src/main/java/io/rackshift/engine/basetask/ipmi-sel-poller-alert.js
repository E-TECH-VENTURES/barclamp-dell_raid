// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Ipmi Sel Poller Alerts',
    injectableName: 'Task.Base.Poller.Alert.Ipmi.Sel',
    runJob: 'Job.Poller.Alert.Ipmi.Sel',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
