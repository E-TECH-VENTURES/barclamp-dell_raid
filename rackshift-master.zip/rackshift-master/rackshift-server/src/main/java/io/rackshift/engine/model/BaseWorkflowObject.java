package io.rackshift.engine.model;

public interface BaseWorkflowObject {
    String getInjectableName();

    String getFriendlyName();
}
