// Copyright © 2017 Dell Inc. or its subsidiaries. All Rights Reserved.

'use strict';

module.exports = {
    friendlyName: 'Dell Wsman RAID Base Task',
    injectableName: 'Task.Base.Dell.Wsman.RAID',
    runJob: 'Job.Dell.Wsman.RAID',
    requiredOptions: [
    ],
    requiredProperties: {
    },
    properties: {
    }
};
