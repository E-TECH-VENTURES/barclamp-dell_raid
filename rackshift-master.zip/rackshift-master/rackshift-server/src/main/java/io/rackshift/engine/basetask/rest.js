// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: "REST.api.call",
    injectableName: "Task.Base.Rest",
    runJob:"Job.Rest",
    requiredOptions:["url", "method"],
    requiredProperties:{},
    properties:{}
};
