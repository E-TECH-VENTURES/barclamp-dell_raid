// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Docker Reconciler Base Task',
    injectableName: 'Task.Docker.Reconciler.Base',
    runJob: 'Job.Docker.Reconciler',
    requiredOptions: [],
    properties: {},
    requiredProperties: []
};
