// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Snmp Requester',
    injectableName: 'Task.Base.Snmp',
    runJob: 'Job.Snmp',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
