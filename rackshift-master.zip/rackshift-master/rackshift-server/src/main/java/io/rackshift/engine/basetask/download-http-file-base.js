// Copyright © 2017 Dell Inc. or its subsidiaries.  All Rights Reserved.

'use strict';

module.exports = {
    friendlyName: 'Download http file',
    injectableName: 'Task.Base.Download.Http.File',
    runJob: 'Job.Download.File',
    requiredOptions: [],
    requiredProperties: {},
    properties:{}
};
