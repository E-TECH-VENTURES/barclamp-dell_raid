// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Test Poller',
    injectableName: 'Task.Base.Test.Poller',
    runJob: 'Job.Test.Poller',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
