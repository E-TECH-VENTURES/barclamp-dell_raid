package io.rackshift.constants;

public class UserStatus {
    public static final String NORMAL = "1";
    public static final String DISABLED = "0";
}
