// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Wsman Requester',
    injectableName: 'Task.Base.Wsman',
    runJob: 'Job.Wsman',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
