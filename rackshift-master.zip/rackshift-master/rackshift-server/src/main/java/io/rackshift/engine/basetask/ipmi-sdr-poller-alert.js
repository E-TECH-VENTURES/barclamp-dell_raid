// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Ipmi Sdr Poller Alerts',
    injectableName: 'Task.Base.Poller.Alert.Ipmi.Sdr',
    runJob: 'Job.Poller.Alert.Ipmi.Sdr',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
