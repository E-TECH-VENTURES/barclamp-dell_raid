// Copyright 2017, Dell EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Wait for SEL events',
    injectableName: 'Task.Base.Wait.Sel.Events',
    runJob: 'Job.Wait.Sel.Events',
    requiredProperties: {},
    properties: {}
};
