package io.rackshift.constants;

public enum ApiKeysConstants {
    ACTIVE,DISABLED
}
