// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Generate Enclosure',
    injectableName: 'Task.Base.Catalog.GenerateEnclosure',
    runJob: 'Job.Catalog.GenerateEnclosure',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};

