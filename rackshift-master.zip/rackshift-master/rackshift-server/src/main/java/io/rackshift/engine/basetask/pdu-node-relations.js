// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'PDU nodes Relations',
    injectableName: 'Task.Base.Catalog.PduRelations',
    runJob: 'Job.Catalog.PduRelations',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};

