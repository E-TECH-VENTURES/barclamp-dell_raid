// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Clean Work Items',
    injectableName: 'Task.Base.WorkItems.Clean',
    runJob: 'Job.WorkItems.Clean',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
