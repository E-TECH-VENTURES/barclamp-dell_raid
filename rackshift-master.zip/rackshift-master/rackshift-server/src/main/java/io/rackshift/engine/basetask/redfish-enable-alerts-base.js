// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: "Enable.Redfish.Alert",
    injectableName: "Task.Base.Redfish.Alert.Enable",
    runJob:"Job.Redfish.Alert.Enable",
    requiredOptions:[],
    requiredProperties:{},
    properties:{}
};
