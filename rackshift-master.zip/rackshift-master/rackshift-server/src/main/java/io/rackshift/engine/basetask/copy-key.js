// Copyright 2016, EMC, Inc.

'use strict';


module.exports = {
    friendlyName: 'Copy Key',
    injectableName: 'Task.Base.Ssh.CopyKey',
    runJob: 'Job.CopySshKey',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
