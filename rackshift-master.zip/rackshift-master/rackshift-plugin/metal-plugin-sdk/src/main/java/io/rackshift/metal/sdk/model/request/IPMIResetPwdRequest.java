package io.rackshift.metal.sdk.model.request;

public class IPMIResetPwdRequest extends IPMICustomRequest {

}
