### RAID Barclamp Licenses

The code and documentation for this barclamp is distributed under the Apache 2 license (http://www.apache.org/licenses/LICENSE-2.0.html). Contributions back to the source are encouraged.



