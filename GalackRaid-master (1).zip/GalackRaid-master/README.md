<img alt="GalackRaid" src="https://i.imgur.com/SNBEHsV.png">  

# GalackRaid

[![](https://img.shields.io/discord/745382663896039496.svg?logo=discord&colorB=7289DA)](https://discord.gg/XH7zQ8s)
[![](https://img.shields.io/badge/discord.js-v12.0.0--dev-blue.svg?logo=npm)](https://github.com/discordjs)
[![](https://img.shields.io/badge/paypal-donate-blue.svg)](https://paypal.me/GalackQSM)

GalackRaid est un bot raid Discord open source codé en JavaScript avec [Discord.js](https://discord.js.org) par [GalackQSM](https://github.com/GalackQSM).  
N'hésitez pas à ajouter une étoile ⭐ au référentiel pour promouvoir le projet!

### Bot

Offres GalackRaid:
*   ✉️ Des commandes RAID
*   🇫🇷 Des commandes de type NORMAL
*   ⚙️ Chaque commande raid faite dans le serveur, le message se supprime
*   😀 Ultra fluide, plus de 600 messages en moins de 3 secondes

### Commandes

GalackRaid a beaucoup de fonctionnalités avec **2 catégories principales**:
# Commande RAID:
* 1help - Afficher les commandes raid
* deletechannels - Supprime tous les salons
* deleteroles - Supprime tous les rôles
* channels [Nom] - Crée 50 salons avec le nom choisis
* spam [Message] - Spams envoyés dans le salon
* kickall - Kicker tout les membres du serveur
* banall - Bannir tout les membres du serveur
* spmall [Message] - Spammer dans tout les salons en même temps
* pmeveryone [Message] - DM tout les membres du serveur

# Commande NORMAL:
* help - Afficher les commandes
* automod - Activer l'automod sur votre serveur
* antilink - Activer l'anti-link sur votre serveur
* cat - Afficher un chat
* dog - Afficher un chien
* weed - Afficher de la weed
* punch - Avoir envie de punch
* calin - Demander un calin

## Installation

* Aller dans le fichier `index.js` et toute a la fin mettez votre token
* Ensuite allez dans CMD et faite `node index.js`

## Liens

*   [Discord](https://discord.gg/XH7zQ8s)
*   [Twitter](https://twitter.com/Galack_QSM)
*   [Github](https://github.com/GalackQSM/)

