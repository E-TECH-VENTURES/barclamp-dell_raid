package io.rackshift.model;

import io.rackshift.mybatis.domain.ExecutionLogDetails;

public class ExecutionLogDetailsDTO extends ExecutionLogDetails {
}
