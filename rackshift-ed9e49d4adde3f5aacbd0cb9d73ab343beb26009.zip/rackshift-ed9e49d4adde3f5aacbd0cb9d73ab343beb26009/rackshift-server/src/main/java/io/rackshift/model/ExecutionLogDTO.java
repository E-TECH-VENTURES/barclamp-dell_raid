package io.rackshift.model;

import io.rackshift.mybatis.domain.ExecutionLog;

public class ExecutionLogDTO extends ExecutionLog {
}
