package io.rackshift.model;

import io.rackshift.mybatis.domain.Image;

public class ImageDTO extends Image {
}
