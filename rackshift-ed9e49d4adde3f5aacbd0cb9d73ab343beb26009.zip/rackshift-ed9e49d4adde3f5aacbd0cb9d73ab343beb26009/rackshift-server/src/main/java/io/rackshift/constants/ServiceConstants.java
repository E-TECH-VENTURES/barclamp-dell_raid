package io.rackshift.constants;

public class ServiceConstants {
    public static final String endPointParameterKey = "main-endpoint";
}
