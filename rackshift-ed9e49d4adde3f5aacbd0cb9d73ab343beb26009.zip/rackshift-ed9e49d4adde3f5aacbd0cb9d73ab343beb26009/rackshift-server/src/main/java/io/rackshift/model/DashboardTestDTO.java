package io.rackshift.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardTestDTO {
    private Long date;
    private Integer count;
}
