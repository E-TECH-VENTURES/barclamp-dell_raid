package io.rackshift.model;

import io.rackshift.mybatis.domain.SystemParameter;

public class SystemParameterDTO extends SystemParameter {
}
