package io.rackshift.model;

import io.rackshift.mybatis.domain.Network;

public class NetworkDTO extends Network {
}
