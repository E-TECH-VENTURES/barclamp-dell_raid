package io.rackshift.utils;

public class RSExceptionsUtils {
}
