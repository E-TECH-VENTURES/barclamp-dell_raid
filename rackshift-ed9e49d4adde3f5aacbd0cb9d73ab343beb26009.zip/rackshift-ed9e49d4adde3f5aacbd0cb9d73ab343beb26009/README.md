# RackShift
## 基于RackHD的一款开源物理机装机方案
###功能特性
【√】RBAC权限管理  
【√】主流品牌裸金属服务器信息管理以及生命周期管控  
【√】Centos定制化kickstart安装工作流  
【√】带外管理  
【√】网络管理  
【√】镜像管理  
【√】执行日志  
![runoob](https://f2c-south.oss-cn-shenzhen.aliyuncs.com/RackHD-dont-del/RackHD%E4%B8%80%E9%94%AE%E5%8C%85/3.0/rs.png)