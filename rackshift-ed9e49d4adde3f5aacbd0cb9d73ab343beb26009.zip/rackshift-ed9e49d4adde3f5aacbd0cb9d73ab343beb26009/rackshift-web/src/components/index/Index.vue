<template>
    <div>ddd</div>
</template>
<style>

</style>

<script>

    export default {
        data() {
            return {
            };
        }
    };
</script>